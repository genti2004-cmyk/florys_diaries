FlorysDiaries v0.18.2 – Assistant-Stabilisierung FIX 2

Dieser Patch ersetzt FIX 1 vollständig.

Korrigiert:
- TravelAssistantAnalyzer übergibt checklistItemCount und
  checklistCompletedCount an TravelAssistantSnapshot.
- Die Werte werden aus allen Reisen summiert. Fehlende oder ungültige
  ältere JSON-Werte werden sicher als 0 behandelt.
- Der Widget-Test enthält beide erforderlichen Parameter.
- Die gemeldeten curly_braces-Lints in professional_world_map.dart
  wurden ohne Änderung der Kartenlogik behoben.

Installation:
1. ZIP direkt in den Projektordner florys_diaries entpacken.
2. Vorhandene Dateien ersetzen.
3. Danach ausführen:

   dart format lib test
   flutter analyze
   flutter test
   flutter run

Backup-, Restore- und Google-Drive-Logik wurden nicht verändert.
