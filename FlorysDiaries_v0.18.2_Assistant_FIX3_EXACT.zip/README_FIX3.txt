FlorysDiaries v0.18.2 FIX 3

Diese Korrektur basiert ausschließlich auf den vier aktuell hochgeladenen Originaldateien.

Geändert:
1. lib/features/assistant/application/travel_assistant_analyzer.dart
   - checklistItemCount wird aus trip.checklistItems.length summiert.
   - checklistCompletedCount wird aus trip.checklistCompletedCount summiert.

2. test/features/assistant/presentation/assistant_widgets_test.dart
   - Beide erforderlichen Snapshot-Parameter wurden ergänzt.

Nicht geändert:
- travel_assistant_models.dart
- trip.dart
- Backup-, Restore- oder Google-Drive-Logik

Installation:
ZIP im Hauptordner florys_diaries entpacken und vorhandene Dateien ersetzen.

Prüfen:
dart format lib test
flutter analyze
flutter test
flutter run
