package com.example.florys_diaries

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
