FlorysDiaries v0.18.2 – Assistant-Stabilisierung FIX 1
======================================================

Korrektur:
- Die Test-Hilfsfunktionen erzeugen Trip-Objekte nicht mehr direkt über
  den Konstruktor.
- Stattdessen wird Trip.fromJson(...) verwendet.
- Dadurch sind die Tests mit Projektständen kompatibel, in denen
  checklistItemCount und checklistCompletedCount Pflichtparameter des
  Trip-Konstruktors sind.
- Beide Checklistenwerte werden in den Testdaten mit 0 initialisiert.

Installation:
1. ZIP direkt in den Projektordner florys_diaries entpacken.
2. Vorhandene Dateien ersetzen.
3. Danach ausführen:

   dart format lib test
   flutter analyze
   flutter test
   flutter run

Geänderte Testdateien gegenüber dem ersten v0.18.2-Paket:
- test/features/assistant/application/travel_assistant_analyzer_test.dart
- test/features/assistant/application/travel_assistant_answer_service_test.dart

Das Paket enthält zusätzlich erneut alle Dateien des ursprünglichen
v0.18.2-Assistant-Patches, damit es vollständig über den Projektordner
entpackt werden kann.
